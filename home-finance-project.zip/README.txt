HOME FINANCE - Upload-friendly package for a NEW GitHub repository

Upload THIS ZIP file as a single file to the repository root. Name it home-finance-project.zip.

Then in GitHub use Add file > Create new file and create the path:
.github/workflows/build-apk.yml
Paste the workflow text supplied separately in ChatGPT, then Commit changes.

The workflow extracts this project ZIP in GitHub Actions and builds the APK.
The previous repository is not modified.
